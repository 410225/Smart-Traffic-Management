import pandas as pd
import numpy as np
from prophet import Prophet
import streamlit as st
import matplotlib.pyplot as plt
import seaborn as sns
import pydeck as pdk
from fpdf import FPDF
from io import BytesIO

# Page config
st.set_page_config(page_title="Smart Traffic Dashboard", layout="wide")

st.title("🚦 Smart Traffic Management System")
st.markdown("""
Welcome to the Smart City Traffic Forecasting Dashboard.
Analyze traffic patterns, filter by junction, weather, and incidents,
and forecast future traffic using advanced ML models.
""")

# Load data
@st.cache_data
def load_data():
    df = pd.read_csv("traffic_data.csv")
    df['Timestamp'] = pd.to_datetime(df['Timestamp'])
    df['Date'] = df['Timestamp'].dt.date
    return df

df = load_data()

# Sidebar filters
st.sidebar.header("📊 Filter Options")
junctions = df['Junction_ID'].unique().tolist()
weather_conditions = df['Weather'].unique().tolist()
incident_status = df['Incident'].unique().tolist()

selected_junction = st.sidebar.selectbox("📍 Select Junction", ["All"] + junctions)
selected_weather = st.sidebar.selectbox("🌦️ Filter by Weather", ["All"] + weather_conditions)
selected_incident = st.sidebar.selectbox("🚨 Filter by Incident", ["All"] + incident_status)
days_to_forecast = st.sidebar.slider("🗓️ Days to Forecast", min_value=7, max_value=60, value=14)
alert_threshold = st.sidebar.number_input("🔔 Alert Threshold (vehicles)", min_value=1000, max_value=50000, value=10000)

# Apply filters
if selected_junction != "All":
    df = df[df['Junction_ID'] == selected_junction]
if selected_weather != "All":
    df = df[df['Weather'] == selected_weather]
if selected_incident != "All":
    df = df[df['Incident'] == selected_incident]

# Group by date for Prophet
daily_data = df.groupby('Date')['Vehicles'].sum().reset_index()
daily_data.columns = ['ds', 'y']
daily_data['ds'] = pd.to_datetime(daily_data['ds'])
daily_data['y'] = daily_data['y'].clip(lower=0)

# Show summary metrics
st.subheader("📈 Traffic Summary")
col1, col2, col3 = st.columns(3)
col1.metric("Today's Traffic", int(daily_data['y'].iloc[-1]))
col2.metric("7-Day Average", int(daily_data['y'].tail(7).mean()))
col3.metric("Total Recorded Vehicles", int(daily_data['y'].sum()))

# Forecasting with Prophet
m = Prophet(weekly_seasonality=True)
m.fit(daily_data)
future = m.make_future_dataframe(periods=days_to_forecast)
forecast = m.predict(future)
forecast['yhat'] = forecast['yhat'].clip(lower=0)
forecast['yhat_lower'] = forecast['yhat_lower'].clip(lower=0)
forecast['yhat_upper'] = forecast['yhat_upper'].clip(lower=0)

# 🚨 Traffic Notification System
max_forecast = forecast['yhat'].tail(days_to_forecast).max()
if max_forecast > alert_threshold:
    st.error(f"🚨 Traffic Alert: Forecasted traffic may exceed {int(max_forecast)} vehicles!")
else:
    st.success(f"✅ Traffic is expected to remain below {alert_threshold} vehicles.")

# Display forecast plot
st.subheader("🔮 Forecasted Traffic Volume")
st.markdown("The black line shows the predicted traffic. The light blue band shows confidence.")
fig1 = m.plot(forecast)
ax1 = fig1.gca()
ax1.set_ylabel("Number of Vehicles")
st.pyplot(fig1)

# Display forecast components with cleaned negative y-axis
st.subheader("🧠 Traffic Pattern Insights")
st.markdown("Trend and weekly seasonality of traffic flow.")
fig2 = m.plot_components(forecast)
for ax in fig2.axes:
    ax.set_ylim(bottom=0)
st.pyplot(fig2)

# Export forecast
st.markdown("### 📤 Download Forecast Data")
forecast_data = forecast[['ds', 'yhat', 'yhat_lower', 'yhat_upper']]
forecast_csv = forecast_data.to_csv(index=False)
st.download_button("Download Forecast CSV", forecast_csv, "forecast.csv", "text/csv")

# PDF Report
st.markdown("### 🧾 Download Traffic Report as PDF")
def create_pdf():
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", size=12)

    pdf.cell(200, 10, txt="Smart Traffic Forecast Report", ln=True, align='C')
    pdf.ln(10)

    pdf.cell(200, 10, txt=f"Today's Traffic: {int(daily_data['y'].iloc[-1])}", ln=True)
    pdf.cell(200, 10, txt=f"7-Day Average: {int(daily_data['y'].tail(7).mean())}", ln=True)
    pdf.cell(200, 10, txt=f"Total Recorded Vehicles: {int(daily_data['y'].sum())}", ln=True)
    pdf.ln(10)

    if max_forecast > alert_threshold:
        pdf.set_text_color(220, 20, 60)
        pdf.cell(200, 10, txt=f"ALERT: Traffic may exceed {int(max_forecast)} vehicles!", ln=True)
        pdf.set_text_color(0, 0, 0)

    pdf.ln(10)
    pdf.cell(200, 10, txt="Note: Forecast plots and trends are not embedded in this version.", ln=True)

    pdf_bytes = pdf.output(dest='S').encode('latin1')
    return BytesIO(pdf_bytes)

pdf_file = create_pdf()
st.download_button("📥 Download PDF Report", data=pdf_file, file_name="traffic_forecast_report.pdf", mime="application/pdf")

# Optional raw data preview
if st.sidebar.checkbox("📋 Show Raw Data"):
    st.subheader("🧾 Raw Traffic Records")
    st.dataframe(df.tail(20))

# 🗺️ Map with mock junction coordinates
st.subheader("📍 Junction Map Overview")
st.markdown("Map view of junctions with simulated coordinates and traffic volume.")

junction_coords = {
    'J1': [-29.8587, 31.0218],
    'J2': [-29.8595, 31.0241],
    'J3': [-29.8572, 31.0182],
    'J4': [-29.8600, 31.0200],
}

map_df = df.groupby('Junction_ID')['Vehicles'].mean().reset_index()
map_df['lat'] = map_df['Junction_ID'].map(lambda x: junction_coords[x][0])
map_df['lon'] = map_df['Junction_ID'].map(lambda x: junction_coords[x][1])

st.pydeck_chart(pdk.Deck(
    map_style=None,
    initial_view_state=pdk.ViewState(
        latitude=-29.858,
        longitude=31.021,
        zoom=14,
        pitch=50,
    ),
    layers=[
        pdk.Layer(
            'ScatterplotLayer',
            data=map_df,
            get_position='[lon, lat]',
            get_color='[200, 30, 0, 160]',
            get_radius='Vehicles',
            pickable=True,
        ),
    ],
))
